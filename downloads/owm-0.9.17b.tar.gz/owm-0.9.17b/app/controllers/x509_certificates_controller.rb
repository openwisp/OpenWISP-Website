# This file is part of the OpenWISP Manager
#
# Copyright (C) 2012 OpenWISP.org
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

class X509CertificatesController < ApplicationController
  before_filter :load_wisp

  access_control do
    default :deny

    actions :show do
      allow :wisps_viewer
      allow :wisp_viewer, :of => :wisp
    end

    actions :revoke, :renew, :reissue do
      allow :wisps_manager
      allow :wisp_manager, :of => :wisp
    end
  end

  # GET /wisps/:wisp_id/ca/x509_certificates/1
  def show
    @ca = @wisp.ca
    @x509_certificate = @ca.x509_certificates.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
    end
  end

  def revoke
    ca = @wisp.ca
    x509_certificate = ca.x509_certificates.find(params[:id])
    ca.revoke_certificate!(x509_certificate)
    
    respond_to do |format|
      format.html { redirect_to(wisp_ca_url(@wisp)) }
    end
  end

  def renew
    ca = @wisp.ca
    x509_certificate = ca.x509_certificates.find(params[:id])
    ca.renew_certificate!(x509_certificate)

    respond_to do |format|
      format.html { redirect_to(wisp_ca_url(@wisp)) }
    end
  end

  def reissue
    ca = @wisp.ca
    x509_certificate = ca.x509_certificates.find(params[:id])
    ca.reissue_certificate!(x509_certificate)

    respond_to do |format|
      format.html { redirect_to(wisp_ca_url(@wisp)) }
    end
  end

end
