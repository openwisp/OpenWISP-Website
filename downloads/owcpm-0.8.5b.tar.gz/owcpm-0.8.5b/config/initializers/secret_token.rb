# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Railscp::Application.config.secret_token = '1f44c5334af44242d4abeb352bb2303421dd1ff0b39132aa77b8dcb6d409460350ea768f5cedf397b0738810573cc9297f40e78ba9b3e7e91e6331705b152f25'
