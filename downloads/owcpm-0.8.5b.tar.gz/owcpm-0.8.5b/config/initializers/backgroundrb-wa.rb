# Workaround for a backgroundrb bug (it doesn't explicitly require 'timeout')

require 'timeout'

