require 'test_helper'

class LocalUsersHelperTest < ActionView::TestCase
end
