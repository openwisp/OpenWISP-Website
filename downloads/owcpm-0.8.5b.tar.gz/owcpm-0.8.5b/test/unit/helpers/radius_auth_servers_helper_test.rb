require 'test_helper'

class RadiusAuthServersHelperTest < ActionView::TestCase
end
