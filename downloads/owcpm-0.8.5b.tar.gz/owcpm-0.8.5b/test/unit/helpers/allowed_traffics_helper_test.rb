require 'test_helper'

class AllowedTrafficsHelperTest < ActionView::TestCase
end
