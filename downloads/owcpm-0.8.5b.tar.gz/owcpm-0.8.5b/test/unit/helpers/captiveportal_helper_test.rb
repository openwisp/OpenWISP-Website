require 'test_helper'

class CaptiveportalHelperTest < ActionView::TestCase
end
