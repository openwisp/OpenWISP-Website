require 'test_helper'

class CaptivePortalHelperTest < ActionView::TestCase
end
