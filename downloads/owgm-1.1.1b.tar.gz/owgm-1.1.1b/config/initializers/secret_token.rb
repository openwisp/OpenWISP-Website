# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Owgm::Application.config.secret_token = 'f7aedfc37a6f7d6f6e709f0831abda89585e3f9a724a73a4a31b29e70b08feb412d7d9b8e93dcd09fb3ba26d3d5f83793a6f12ac47e996a23f7818f620746c68'
