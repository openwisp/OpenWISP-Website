require 'test_helper'

class PropertySetHelperTest < ActionView::TestCase
end
