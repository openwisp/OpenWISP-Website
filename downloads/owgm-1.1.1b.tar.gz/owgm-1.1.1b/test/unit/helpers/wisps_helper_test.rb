require 'test_helper'

class WispsHelperTest < ActionView::TestCase
end
