require 'test_helper'

class ActivityHistoryHelperTest < ActionView::TestCase
end
