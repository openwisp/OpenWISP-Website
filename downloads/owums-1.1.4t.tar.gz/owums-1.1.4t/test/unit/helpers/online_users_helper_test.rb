require 'test_helper'

class OnlineUsersHelperTest < ActionView::TestCase
end
