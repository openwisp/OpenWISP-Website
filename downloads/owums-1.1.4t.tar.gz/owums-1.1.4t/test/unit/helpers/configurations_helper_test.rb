require 'test_helper'

class ConfigurationsHelperTest < ActionView::TestCase
end
