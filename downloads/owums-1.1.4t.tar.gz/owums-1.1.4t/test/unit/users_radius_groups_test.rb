require 'test_helper'

class UsersRadiusGroupsTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  test "the truth" do
    assert true
  end
end
