# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Owums::Application.config.secret_token = 'f276a4b3f2a9ada3659663aff0cd59d5275b7c1d3f9b7da42a4d44dd6804cb36b64d625bb1e186797ae08ec8479722167d289e139cf99b2e192713166cbe63f3'
